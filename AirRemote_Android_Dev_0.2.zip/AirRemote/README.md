# AirRemote 空调遥控器 Android 项目（开发版 0.2）

这是 Kotlin + Jetpack Compose 的 Android 项目源代码，包含：
- 空调控制界面与温度/模式/风速/扫风的界面状态
- 多个中英文品牌的选择列表
- Android ConsumerIrManager 红外发射器检测与原始波形发送封装
- 为后续加入离线红外协议编码器预留的结构

## 重要：当前不是可直接使用的成品遥控器

当前版本**没有集成可验证的空调协议编码器，也没有已验证的空调红外码库**。按钮用于界面交互和原型验证，不会让真实空调改变状态。品牌出现在列表里仅表示可选择，不代表该品牌已受支持。

空调遥控器通常不是一组简单的固定开关码：许多型号每次都要发送完整状态（模式、温度、风速、扫风等），还涉及校验和、位序与载波频率。因此不能随意填入“通用码”并宣称能用。

## 开源协议参考

后续协议研究可参考开源项目 IRremoteESP8266：
https://github.com/crankyoldgit/IRremoteESP8266

该库面向 ESP8266/ESP32 微控制器，并非可直接复制到 Android 手机的 Java/Kotlin 码库。将其协议移植到 Android `ConsumerIrManager` 需要逐协议实现编码，并检查相关许可证要求。

## 构建要求

需要安装 Android Studio 与 Android SDK 的电脑来构建 APK。当前 ZIP 是源代码项目，不是 APK 安装包；此环境没有 Android SDK/Gradle 构建环境，因此没有声称已编译或测试 APK。

1. 解压 ZIP。
2. 用 Android Studio 打开 `AirRemote` 文件夹（其中有 `settings.gradle.kts`）。
3. 等待 Gradle 同步，然后构建 APK。
4. 在支持红外发射的 Android 真机上验证系统红外服务和具体空调协议。

## 手机兼容性

代码使用 Android `ConsumerIrManager`。手机即使有红外硬件，也需要系统对应用开放对应服务。`transmit()` 成功只表示系统接受了波形，并不保证空调收到或理解指令。
