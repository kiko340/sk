package com.example.airremote.infrared

import android.content.Context
import android.hardware.ConsumerIrManager

/**
 * Sends raw IR patterns. A valid pattern must come from a real protocol/code set.
 * Successful transmit() means Android accepted the waveform, not that the AC responded.
 */
class PhoneIrController(context: Context) {
    private val manager =
        context.getSystemService(Context.CONSUMER_IR_SERVICE) as? ConsumerIrManager

    fun isAvailable(): Boolean = manager?.hasIrEmitter() == true

    fun supportedCarrierRanges(): List<IntRange> =
        manager?.carrierFrequencies?.map { it.minFrequency..it.maxFrequency } ?: emptyList()

    fun transmit(carrierHz: Int, patternMicros: IntArray): Result<Unit> {
        val ir = manager ?: return Result.failure(IllegalStateException("系统未提供红外服务"))
        if (!ir.hasIrEmitter()) return Result.failure(IllegalStateException("没有检测到红外发射器"))
        if (carrierHz <= 0 || patternMicros.isEmpty() || patternMicros.any { it <= 0 }) {
            return Result.failure(IllegalArgumentException("红外参数无效"))
        }
        return runCatching { ir.transmit(carrierHz, patternMicros) }
    }
}
