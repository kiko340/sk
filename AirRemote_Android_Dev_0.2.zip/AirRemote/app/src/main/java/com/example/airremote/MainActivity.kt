package com.example.airremote

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.airremote.infrared.PhoneIrController
import com.example.airremote.model.ACMode
import com.example.airremote.model.FanSpeed
import com.example.airremote.model.commonBrands

private val pageBg = Color(0xFFF1F5FA)
private val ink = Color(0xFF26364A)
private val blue = Color(0xFF3478F6)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val ir = PhoneIrController(this)
        setContent {
            MaterialTheme {
                Surface(Modifier.fillMaxSize(), color = pageBg) {
                    AirRemoteApp(ir)
                }
            }
        }
    }
}

@Composable
private fun AirRemoteApp(ir: PhoneIrController) {
    var selectedBrand by remember { mutableStateOf("选择品牌") }
    var temperature by remember { mutableIntStateOf(26) }
    var isOn by remember { mutableStateOf(false) }
    var mode by remember { mutableStateOf(ACMode.COOL) }
    var speed by remember { mutableStateOf(FanSpeed.AUTO) }
    var swing by remember { mutableStateOf(true) }
    var showBrands by remember { mutableStateOf(false) }
    var message by remember {
        mutableStateOf(
            if (ir.isAvailable()) "已检测到手机红外硬件。请选择品牌并匹配码组。" 
            else "暂未检测到系统红外服务，请确认手机型号及系统支持。"
        )
    }

    Column(
        modifier = Modifier.fillMaxSize().padding(18.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("AirRemote", fontSize = 27.sp, fontWeight = FontWeight.Bold, color = ink)
        Text("多品牌空调遥控器 · 本地控制", color = Color(0xFF718096))
        Spacer(Modifier.height(18.dp))

        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(28.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFFDCEAF7))
        ) {
            Column(
                Modifier.fillMaxWidth().padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(if (isOn) mode.title else "待机", color = ink, fontSize = 16.sp)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(if (isOn) "$temperature" else "--", fontSize = 68.sp, color = ink)
                    Text("°C", fontSize = 23.sp, color = ink)
                }
                Text("$selectedBrand  ·  风速：${speed.title}", color = Color(0xFF60758A))
            }
        }

        Spacer(Modifier.height(14.dp))
        OutlinedButton(
            onClick = { showBrands = true },
            modifier = Modifier.fillMaxWidth()
        ) { Text("选择空调品牌：$selectedBrand") }

        Spacer(Modifier.height(14.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            RemoteButton(if (isOn) "⏻ 关机" else "⏻ 开机", Modifier.weight(1f), isOn) {
                isOn = !isOn
                message = "状态已切换。当前版本尚未配置真实空调码组，因此没有发送空调指令。"
            }
            RemoteButton("切换模式", Modifier.weight(1f)) {
                mode = ACMode.entries[(ACMode.entries.indexOf(mode) + 1) % ACMode.entries.size]
                message = "已选择${mode.title}。匹配码组后才能发送实际指令。"
            }
        }
        Spacer(Modifier.height(12.dp))

        Card(colors = CardDefaults.cardColors(containerColor = Color.White)) {
            Row(
                Modifier.fillMaxWidth().padding(8.dp),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically
            ) {
                TextButton(onClick = { if (temperature > 16) temperature-- }) {
                    Text("−", fontSize = 30.sp)
                }
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("设定温度", color = Color.Gray)
                    Text("$temperature°C", fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
                }
                TextButton(onClick = { if (temperature < 30) temperature++ }) {
                    Text("+", fontSize = 30.sp)
                }
            }
        }

        Spacer(Modifier.height(12.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            RemoteButton("风速：${speed.title}", Modifier.weight(1f)) {
                speed = FanSpeed.entries[(FanSpeed.entries.indexOf(speed) + 1) % FanSpeed.entries.size]
                message = "风速已选择${speed.title}。"
            }
            RemoteButton("扫风：${if (swing) "开" else "关"}", Modifier.weight(1f), swing) {
                swing = !swing
                message = "扫风状态已切换。"
            }
        }

        Spacer(Modifier.height(14.dp))
        Card(colors = CardDefaults.cardColors(containerColor = Color.White)) {
            Column(Modifier.fillMaxWidth().padding(14.dp)) {
                Text("设备状态", fontWeight = FontWeight.Bold, color = ink)
                Spacer(Modifier.height(6.dp))
                Text(message, color = Color(0xFF59697D), fontSize = 13.sp)
                Spacer(Modifier.height(8.dp))
                Text(
                    "提示：界面已可交互；真实控制需要加入经过验证的品牌红外协议/码组。",
                    color = Color(0xFF9A5B00), fontSize = 12.sp
                )
            }
        }
    }

    if (showBrands) {
        AlertDialog(
            onDismissRequest = { showBrands = false },
            title = { Text("选择空调品牌") },
            text = {
                LazyVerticalGrid(
                    columns = GridCells.Fixed(2),
                    modifier = Modifier.heightIn(max = 420.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    items(commonBrands) { brand ->
                        Surface(
                            modifier = Modifier.fillMaxWidth().clickable {
                                selectedBrand = brand.name
                                showBrands = false
                                message = "已选择${brand.name}。下一步需要匹配这个品牌的红外码组。"
                            },
                            shape = RoundedCornerShape(12.dp),
                            color = Color(0xFFF0F4FA)
                        ) {
                            Text(
                                brand.name,
                                Modifier.padding(12.dp),
                                color = ink
                            )
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showBrands = false }) { Text("关闭") }
            }
        )
    }
}

@Composable
private fun RemoteButton(
    text: String,
    modifier: Modifier = Modifier,
    active: Boolean = false,
    onClick: () -> Unit
) {
    Surface(
        modifier = modifier.heightIn(min = 58.dp),
        shape = RoundedCornerShape(18.dp),
        color = if (active) Color(0xFFDCE8FF) else Color.White,
        shadowElevation = 2.dp,
        onClick = onClick
    ) {
        Box(Modifier.fillMaxWidth().padding(12.dp), contentAlignment = Alignment.Center) {
            Text(text, color = if (active) blue else ink, fontSize = 14.sp)
        }
    }
}
