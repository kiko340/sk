package com.example.airremote.model

enum class ACMode(val title: String, val icon: String) {
    COOL("制冷", "❄"),
    HEAT("制热", "☀"),
    DRY("除湿", "💧"),
    FAN("送风", "≋"),
    AUTO("自动", "A")
}

enum class FanSpeed(val title: String) {
    AUTO("自动"), LOW("低速"), MEDIUM("中速"), HIGH("高速")
}

data class ACBrand(val name: String, val note: String = "需匹配具体红外协议")

// Brand names are choices in the UI, not a claim that codes for every brand are implemented.
val commonBrands = listOf(
    "格力", "美的", "海尔", "奥克斯", "TCL", "海信", "长虹", "科龙", "志高", "春兰",
    "大金", "松下", "日立", "三菱电机", "三菱重工", "富士通", "东芝", "夏普", "LG", "三星",
    "开利", "约克", "特灵", "麦克维尔", "博世", "伊莱克斯", "惠而浦", "飞利浦",
    "Carrier", "Daikin", "Fujitsu", "Gree", "Haier", "Hisense", "Hitachi", "LG", "Midea",
    "Mitsubishi Electric", "Panasonic", "Samsung", "Sharp", "TCL", "Toshiba", "Whirlpool",
    "York", "其他 / 不确定"
).distinct().map { ACBrand(it) }
